
document.addEventListener('DOMContentLoaded', function() {
  const content = document.getElementById('russian-text');
  // ניתן להרחיב כאן עם מנוע זיהוי בהמשך
  console.log("תוכן נטען:", content.textContent);
});
